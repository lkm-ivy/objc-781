int GC(void) { return 42; }
